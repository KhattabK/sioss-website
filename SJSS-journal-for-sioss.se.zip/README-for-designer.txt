SIOSS Journal of Sport Science (SJSS) - journal section for www.sioss.se
=======================================================================

What this is
  A ready-made static section for the journal. Plain HTML + one CSS file, no build step,
  no dependencies. It does not touch any existing file of the site.

How to install (2 steps)
  1. Copy the whole "journal" folder into the root of the site project, next to index.html,
     and deploy as usual. The journal will then be at  https://www.sioss.se/journal/
  2. Add a link to it in the main navigation of index.html (and in the footer list), e.g.

         <a href="journal/">Journal</a>

     If the menu labels come from i18n.js, add a key for it (EN: "Journal", plus the Arabic label).

Contents of the folder
  index.html            journal home
  about.html            aims, scope and policies
  editorial-board.html  editorial board
  authors.html          guide for authors + submission
  peer-review.html      peer review process
  archive.html          all issues
  articles/             one page per article (with Google Scholar meta tags)
  pdf/                  article PDFs and the full issue
  files/                paper template (.docx)
  journal.css           styles (same palette and fonts as the main site)

Notes
  - Article pages contain absolute URLs under https://www.sioss.se/journal/ in their meta tags,
    so the folder must keep the name "journal" and sit at the site root.
  - Recommended: add the journal URLs to a sitemap.xml (the site currently has none).